import { createStore, applyMiddleware } from 'redux';
import { persistStore } from 'redux-persist';
import thunk from 'redux-thunk';
import rootReducer from './reducers'; // Assicurati che rootReducer sia corretto

// Crea l'enhancer con il middleware (senza Redux DevTools)
const enhancer = applyMiddleware(thunk);

// Crea lo store con il reducer root e l'enhancer
export const store = createStore(rootReducer, enhancer);

// Crea il persistor
export const persistor = persistStore(store);
