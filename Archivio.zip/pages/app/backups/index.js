import LayoutTopBar from "@/components/layout/layoutTopBar";

export default function Backups() {
    return <LayoutTopBar title="Backups">

    </LayoutTopBar>
}
