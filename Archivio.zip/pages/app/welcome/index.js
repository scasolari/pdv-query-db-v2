import LayoutTopBar from "@/components/layout/layoutTopBar";

export default function Welcome() {
    return <LayoutTopBar title="Welcome">

    </LayoutTopBar>
}
