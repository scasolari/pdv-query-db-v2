import LayoutTopBar from "@/components/layout/layoutTopBar";

export default function Dashboard() {
    return <LayoutTopBar title="Dashboard">

    </LayoutTopBar>
}
