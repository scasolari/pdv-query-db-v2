import LayoutTopBar from "@/components/layout/layoutTopBar";

export default function Databases() {
    return <LayoutTopBar title="Databases">

    </LayoutTopBar>
}
