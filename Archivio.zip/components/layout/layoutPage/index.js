export default function LayoutPage({ children, title }) {
    return <div>
        {children}
    </div>
}
