-- AlterTable
ALTER TABLE `Member` ADD COLUMN `status` VARCHAR(191) NOT NULL DEFAULT 'pending';
