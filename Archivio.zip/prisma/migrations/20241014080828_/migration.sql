-- AlterTable
ALTER TABLE `Organization` ADD COLUMN `members` JSON NULL;
