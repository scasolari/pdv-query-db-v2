/*
  Warnings:

  - Added the required column `organizationOwner` to the `Member` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `Member` ADD COLUMN `organizationOwner` VARCHAR(191) NOT NULL;
